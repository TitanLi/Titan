module.exports = TransDate;

function TransDate() {

};

TransDate.prototype.getDate = function(timezone) {
  var utc = new Date();
  utc = utc.getTime() + (utc.getTimezoneOffset() * 60000);
  utc += (3600000 * timezone);
  return new Date(utc);
};

TransDate.prototype.format = function(date, fstr) {
  return fstr.replace(/%[YmdHMS]/g, function(m) {
    switch (m) {
      case '%Y':
        return date['getFullYear'](); // no leading zeros required
      case '%m':
        m = 1 + date['getMonth']();
        break;
      case '%d':
        m = date['getDate']();
        break;
      case '%H':
        m = date['getHours']();
        break;
      case '%M':
        m = date['getMinutes']();
        break;
      case '%S':
        m = date['getSeconds']();
        break;
      default:
        return m.slice(1); // unknown code, remove %
    }
    // add leading zero if required
    return ('0' + m).slice(-2);
  });
};
