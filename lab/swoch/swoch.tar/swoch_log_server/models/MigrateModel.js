var config = require('../config.json');
var Sequelize = require('sequelize');
var sequelize = new Sequelize(
  config.database.database,
  config.database.account,
  config.database.password, {
    timezone: config.database.timezone,
    host: config.database.host,
    dialect: config.database.type,

    pool: {
      max: config.database.max_connect,
      min: config.database.min_connect,
      idle: config.database.idle
    }
  });



var Record = sequelize.define('records', {
  eid: {
    type: Sequelize.STRING,
    field: 'eid' // Will result in an attribute that is firstName when user facing but first_name in the database
  },
  info: {
    type: Sequelize.STRING,
    field: 'info'
  }
}, {
  freezeTableName: true // Model tableName will be the same as the model name
});

Record.sync({
  force: false
});

module.exports = Record;
