var mkdirp = require('mkdirp');

module.exports = CsvDirMd;

function CsvDirMd() {
  this.prevDir = '';
  this.year = 0;
  this.month = 0;
  this.monthDate = 0;
  this.hour = 0;
};

CsvDirMd.prototype.setPrevDir = function(path) {
  this.prevDir = path;
};

CsvDirMd.prototype.addCarry = function(value) {
  return (value < 10) ? '0' + value : value;
};

CsvDirMd.prototype.setDate = function(date) {
  this.year = date.getFullYear();

  this.month = this.addCarry(date.getMonth() + 1);

  this.monthDate = this.addCarry(date.getDate());

  this.hour = date.getHours();
};

CsvDirMd.prototype.mk = function(callBack) {
  var year = this.year;
  var month = this.month;
  var monthDate = this.monthDate;
  var hour = this.hour;

  var dir = this.prevDir + year + '/' + month + '/' + monthDate;

  mkdirp(dir, function() {

    console.log('\033[0;36m----------------- make dir as ' + dir + ' -----------------\033[0m');

    if (callBack) {
      var timeObject = {
        year: year,
        month: month,
        monthDate: monthDate,
        hour: hour
      };

      callBack(dir, timeObject);
    }

  });
};
