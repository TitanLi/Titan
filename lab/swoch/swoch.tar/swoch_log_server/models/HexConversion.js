module.exports = HexConversion;

function HexConversion() {

};

HexConversion.prototype.tenToHex = function(parameters) {
  var data = [];
  parameters.forEach(function(parameter) {

    var str = '';
    if (parameter < 16) {
      str += '0';
    }
    str += parameter.toString(16);
    data.push(str);

  });

  return data;
};
