var fs = require('fs');
var express = require('express');
var request = require('sync-request');
var app = express();
var fileIdIp = process.env.ID_API_IP || 'http://211.23.17.100:6969/api/elevator';


function ymd(value, min, max) {
  var tmpOption = '';
  for (var i = min; i <= max; i++) {
    var tmpStr = '';
    if (i == value) {
      tmpStr = 'selected';
    }
    var tmp = (i < 10) ? '0' + i : i;
    tmpOption += '<option value="' + tmp + '"' + tmpStr + '>' + tmp + '</option>';
  }
  return tmpOption;
}

function setYMD(year, month, date) {
  var yearOption = ymd(year, 2015, 2018);
  var monthOption = ymd(month, 1, 12);
  var dateOption = ymd(date, 1, 31);
  return [yearOption, monthOption, dateOption];
}

function walk(path, callBack) {
  try {
    var dirList = fs.readdirSync(path);
    dirList.forEach(function(item) {
      if (fs.statSync(path + '/' + item).isDirectory()) {
        walk(path + '/' + item, callBack);
      } else {
        callBack(path, item);
      }
    });
  } catch (e) {}
}

app.use('/csv_log', express.static('csv_log'));
app.get('/', function(req, res) {
  var fileIds = {};
  var id = (req.query.id) ? req.query.id : '';
  var date = null;
  var str = '';
  var reqYMD = setYMD(req.query.year, req.query.month, req.query.date);
  str += '<div><form method="get"><select name="year">' + reqYMD[0] + '</select><select name="month">' + reqYMD[1] +
    '</select><select name="date">' + reqYMD[2] + '</select><input name="id" value="' + ((req.query.id) ? req.query.id : '') + '"><input type="submit" value="查詢"></form></div>';

  if (!req.query.year || !req.query.month || !req.query.date) {
    str += '<div><h1>請選擇日期</h1></div>';
  } else {
    date = req.query.year + '/' + req.query.month + '/' + req.query.date;
    var fileList = [];

    var callBack = function(path, item) {
      var file = '(.*?)' + id + '.csv';
      if (item.match(file)) {
        fileList.push(path + '/' + item);
      }
    };

    walk('csv_log/' + date, callBack);
    if (fileList.length == 0) {
      str += '<div><h1>查無此結果.</h1></div>';
    } else {
      str += '<div><h1>以下皆為UTC時區,請自行下載並轉換成台北時區.</h1></div>';
      fileList.forEach(function(value) {
        var tmpStr = value.split('/')[4].split('_');
        var logTimeStamp = tmpStr[1];
        var fileId = tmpStr[2].split('.')[0];
        if (!fileIds[fileId]) {
          fileIds[fileId] = {
            name: fileId
          };
          var getResponse = request('GET', fileIdIp + '/' + fileId);
          if (getResponse.getBody('utf8')) {
            fileIds[fileId] = JSON.parse(getResponse.getBody('utf8'));
            fileIds[fileId].name += '_' + fileId;
          }
        }
        str += '<div><a href="' + value + '">' + logTimeStamp + '_' + fileIds[fileId].name + '</a><div>';
      });
    }
  }
  res.send(str);

});

var server = app.listen(3000, function() {
  var host = server.address().address;
  var port = server.address().port;

  console.log('Example app listening at http://%s:%s', host, port);
});
