var ioRedis = require('ioredis');

var redisPort = process.env.REDIS_PORT || 6379;
var redisIp = process.env.REDIS_IP || '127.0.0.1';

var redis = new ioRedis(redisPort, redisIp);

var record = require('./models/MigrateModel');
var hexConversion = new(require('./models/HexConversion'));

console.log('Log server has listen redis ' + redisIp + ':' + redisPort);

redis.subscribe(['status', 'command'], function(err, count) {});

redis.on('message', function(channel, data) {

  var result = {
    eid: null,
    info: []
  };

  data = JSON.parse(data);
  if (data.transType == 'data') {

    if (channel == 'status') {
      result.eid = data.eid;
      result.info = hexConversion.tenToHex(data.info.data).join(',');
    }

    if (channel == 'command') {
      result.eid = data.id;
      result.info = hexConversion.tenToHex(data.command).join(',');
    }

    if (result.eid) {
      console.log('save data into sql. type:' + channel);
      record.create(result);
    }
  }

});
