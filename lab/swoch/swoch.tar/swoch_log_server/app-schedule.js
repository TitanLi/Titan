var fs = require('fs');
var csv = require('fast-csv');
var schedule = require('node-schedule');

var config = require('./config.json');
var recordTable = require('./models/MigrateModel');
var csvDir = new(require('./models/CsvDirMd'));
var transDate = new(require('./models/TimezoneTrans'));

var timezone = config.timezone;

var rule = new schedule.RecurrenceRule();

rule.minute = 1;
rule.second = 0;
//rule.second = [0, 10, 20, 30, 40, 50];

csvDir.setPrevDir(config.csv_prefix_dir);

schedule.scheduleJob(rule, function() {

  csvDir.setDate(transDate.getDate(timezone));
  csvDir.mk(dirmkCallback);

});


function csvNameSpace(year, month, monthDate, hour) {
  var createTime = transDate.getDate(timezone - 1);
  var fileName = transDate.format(createTime, "log_%Y%m%d%H_");

  return fileName;
};

function dirmkCallback(hasMadeDir, time) {

  time.hour--;
  if (time.hour < 10) {
    time.hour = '0' + time.hour;
  }
  var csvLog = [];
  var logFileName = csvNameSpace(time.year, time.month, time.monthDate, time.hour);
  var createTime = time.year + '-' + time.month + '-' + time.monthDate + ' ' + time.hour;

  console.log('\033[0;36m-----------------' + logFileName + '*.csv start -----------------\033[0m');

  recordTable.findAll({
    where: {
      createdAt: {
        $gte: createTime + ':00:00',
        $lte: createTime + ':59:59'
      }
    }
  }).then(function(records) {
    if (records.length) {
      console.log('\033[0;36m----------------- has data -----------------\033[0m');
    } else {
      console.log('\033[0;36m----------------- empty -----------------\033[0m');
    }

    records.forEach(function(record) {
      var id = record.eid;
      var info = record.info;
      var created = '[' + transDate.format(record.createdAt, "%H:%M:%S") + ']';

      if (!csvLog[id]) {
        console.log(logFileName + id + '.csv create...');
        csvLog[id] = csv.createWriteStream({
          headers: false
        });
        csvLog[id].pipe(fs.createWriteStream(hasMadeDir + '/' + logFileName + id + '.csv'));
      }

      csvLog[id].write([created, info]);

    });


    csvLog.forEach(function(element, index, arr) {
      csvLog[index].end();
      console.log(logFileName + index + '.csv close...');
    });

    console.log('\033[0;36m-----------------' + logFileName + '*.csv finish -----------------\033[0m');

  });

}
