var ioRedis = require('ioredis');
var request = require('request');


var redisPort = process.env.REDIS_PORT || 6379;
var redisIp = process.env.REDIS_IP || '127.0.0.1';
var errorCodeServerIp = process.env.ERROR_SERVER_IP || '211.23.17.100:23432';

var redis = new ioRedis(redisPort, redisIp);

console.log('Log-error-code server has listen redis ' + redisIp + ':' + redisPort);

redis.subscribe(['status', 'command'], function(err, count) {});

redis.on('message', function(channel, data) {

  data = JSON.parse(data);
  if (data.transType == 'data') {

    if (channel == 'status') {
      var info = {
        id: data.eid,
        command: data.info.data
      }

      switch (info.command[1]) {
        case 0x85:
          switch (info.command[2]) {
            case 0x05:
              errorCodeEvent(info.id, info.command[3]);
              break;

          }
          break;

      }

    }

  }

});

function errorCodeEvent(id, errorCode) {
  console.log("request server_ip:" + errorCodeServerIp + " id:" + id + " error_code:" + errorCode);
  request('http://' + errorCodeServerIp + '/api/gate/record/' + id + '/' + errorCode, function(error, response, body) {
    if (!error && response.statusCode == 200) {
      console.log('request ok!');
    } else {
      console.log('server error: ' + error);
    }
  });
}
