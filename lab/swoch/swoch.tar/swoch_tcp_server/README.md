# 利用Redis溝通兩個NodeJS之間的橋樑
利用第一個nodejs端當作底層TCP的傳輸過程，並且把所處理過的資料透過redis給另外一個nodejs使用。
本次測試透過TCP client端發送消息給TCP Server並透過redis溝通另外一個nodejs再把過濾的訊息回傳回來。

# 2015/10/20新增
##### 1.TCP 新增排程，觸發時產生從Mysql抓資料下來產生csv檔案
##### 2.TCP 新增ORM與MySQl溝通

## 初始設定
### 啟動並執行

在 ` redis ` 裡面 `channel1` 為  ` TCP Server接收端 ` 以及 ` API Server傳送端 `， `channel2` 為  ` TCP Server傳送端 ` 以及 ` API Server接收端 。

在 ` TCP Client` 裡面輸入 command的規則為 ` id,message `。舉例來說，我電梯ID為` 100 `，電梯現在狀態為 ` 在1樓 `，哪麼輸入資料則需為　` 100,在一樓 ` 

------

###### 1.啟動TCP Server

底層溝通端並透過Redis溝通API Server。

```shell
  node tcp-server.js
```

###### 2.啟動TCP Client
模擬電梯的底層Client端。

```shell
  node tcp-client.js
```

###### 3.啟動API Server

後端功能api Server供控制中心的中介點。


```shell
  node api-server.js
```

###### 4.電梯控制網頁 

模擬控制中心。


利用網頁瀏覽器打開 ` api-client.html `

###### 5.啟動redis


打開 ` redis-server `

------

### 系統流程

####  1.English

``` TCP_Client  <->  TCP_Server <-> Redis_Server <-> Api_Server <-> 控制中心 ``` 

####  2.中文

``` 電梯  <->  TCP底端伺服器<-> Redis伺服器<-> API後端伺服器 <-> 控制中心前端 ```

#### 3.Picture&圖片

![Screenshot](https://makenotion-test.s3.amazonaws.com/21e53fb4-5ae1-400b-aa8f-22d259d73110/architecture_3.png)

------
### 畫面流程

##### 1.電梯發送現在狀態 

![Screenshot](http://211.23.17.100/sowch_elevc/picture1.png)


##### 2.電梯控制中心接收到電梯的狀態

![Screenshot](http://211.23.17.100/sowch_elevc/picture2.png)


##### 3.電梯控制中心傳送給指定電梯Command

![Screenshot](http://211.23.17.100/sowch_elevc/picture3.png)


##### 4.在控制中心同步更新電梯狀態

![Screenshot](http://211.23.17.100/sowch_elevc/picture4.png)

參考:<https://github.com/jigsawye/node-udp-tcp-demo>