const net = require('net');
const deepEqual = require('deepequal');
var tcpRedis = new(require('./models/TcpRedis'));
const fs = require('fs');
const join = require('path').join;
const helper = join(__dirname, 'helper');
const tcpPort = process.env.PORT || 8080;
const socketTimeout = parseInt(process.env.SOCKET_TIMEOUT || 10000);

var clients = [];
var clientsIds = [];

fs.readdirSync(helper)
  .filter(file => ~file.search(/^[^\.].*\.js$/))
  .forEach(file => require(join(helper, file)));

tcpRedis.hasDataCallback = function(data) {
  if (clients[data.id]) {
    console.log("id:" + data.id + "has command.");
    clients[data.id].write(new Buffer(data.command));
  }
};

tcpRedis.hasCommunicationCallback = function(data) {
  switch (data.type) {
    case 'get_all_data':
      clientsIds.forEach(function(clientId) {
        var result = {
          eid: clientId,
          info: null,
        };

        clients[clientId].cmdTypes.forEach(function(cmdType) {
          if (clients[clientId].prevStatus[cmdType]) {
            result.info = clients[clientId].prevStatus[cmdType];
            tcpRedis.sendData(result, cmdType);
          }
        });
      });
      break;
    default:
      break;
  }

};

tcpRedis.stratRedis();

var tcp = net.createServer(function(socketClient) {
  var id = '';
  var error = '';

  socketClient.prevStatus = {};
  socketClient.cmdTypes = [];

  console.log("has a clinet Connect but dont know id");

  socketClient.setTimeout(socketTimeout, function() {
    error = "long time no data.";
    socketClient.destroy();
  });


  socketClient.on('data', function(data) {
    if (data.length <= 20) {

      id = '';
      data.slice(0, 4).forEach(function(uid) {
        var uStr = uid.toString(16);
        if (uStr.length == 1) {
          uStr = "0" + uStr;
        }
        id += uStr;
      });


      if (clients[id] != socketClient) {
        console.log("a client connect. id:" + id);
        clients[id] = socketClient;
        clientsIds.push(id);
      }

      data = data.slice(4, data.length);
      const type1 = (data[1] & 0xf0);
      const isSpeed00F9 = ((type1 == 0x00) && (data[2] == 0x00) && (data[3] == 0xf9));
      var cmdType = type1.toString(16) + '_' + data[2].toString(16);
      cmdType = (isSpeed00F9) ? '00_00_f9' : cmdType;
      const isErrorCode = ((cmdType == '80_5'));
      const isCmdTypeNull = (socketClient.prevStatus[cmdType] == null);

      if (isSpeed00F9 || isErrorCode || isCmdTypeNull || (!deepEqual(socketClient.prevStatus[cmdType], data))) {
        if ((!isSpeed00F9) && (!isErrorCode)) {
          if (isCmdTypeNull) {
            clients[id].cmdTypes.push(cmdType);
            if (cmdType == '80_1') {
              const ledCommand = [0xab, 0x07, 0x80, 0xf9, 0x6a, 0x08, 0x63];
              socketClient.write(new Buffer(ledCommand));
              console.log("a server has command to Elevc. type:data cmdType:07_80 id:" + id);
            }
          }
          socketClient.prevStatus[cmdType] = data;
        }
        const result = {
          eid: id,
          info: data,
        };
        tcpRedis.sendData(result, cmdType);
      }

    }

  });

  socketClient.on('error', function(errorMessage) {
    error = errorMessage;
    socketClient.destroy();
  });

  socketClient.on('close', function() {
    error = (error != '') ? error : "clinet onclick disconnect.";
    console.log("a client disconnect. id:" + id + " error:" + error);

    var result = {
      eid: id,
      type: 'elevc_disconnect'
    };

    tcpRedis.sendCommunication(result);

    clients.deleteByKeyAndClean(id);
    if (clientsIds.isExistByValue(id)) {
      clientsIds.deleteByValueAndClean(id);
    }
  });

});


tcp.listen(tcpPort, function() {
  console.log('TCP Server listening on Port:' + tcpPort);
});
