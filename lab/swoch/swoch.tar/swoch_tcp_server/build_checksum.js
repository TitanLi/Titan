	var command = [0xab,0x07,0x80,0xf9,0x6a,0x08];
	var tmp = 0;
    command.forEach(function(value){
        tmp += value;
    });
    tmp &= 0xff;
    tmp = 0xff - tmp +0x01;
    tmp %= 0x100;

    command[command.length] = tmp;

    console.log(tmp.toString(16));