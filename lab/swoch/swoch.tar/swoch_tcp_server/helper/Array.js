Array.prototype.deleteByValueAndClean = function(value) {
  this.splice(this.indexOf(value), 1);
  return this;
};

Array.prototype.deleteByKeyAndClean = function(key) {
  this.splice(key, 1);
  return this;
};

Array.prototype.isExistByValue = function(value) {
  return (this.indexOf(value) != -1);
};

Array.prototype.clean = function(deleteValue) {
  for (var i = 0; i < this.length; i++) {
    if (this[i] == deleteValue) {
      this.splice(i, 1);
      i--;
    }
  }
  return this;
};
