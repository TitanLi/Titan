var timezoneTrans = new(require('./TimezoneTrans.js'));

var redisPort = process.env.REDIS_PORT || 6379;
var redisIp = process.env.REDIS_IP || '127.0.0.1';
var timezone = process.env.TIMEZONE || 0;

var ioRedis = require('ioredis');
var redisReceive = new ioRedis(redisPort, redisIp);
var redisSend = new ioRedis(redisPort, redisIp);

//published channel :status
//subscribe channel :command
redisReceive.subscribe('command', function(err, count) {});

module.exports = TcpRedis;

function TcpRedis() {

  this.hasDataCallback = null;
  this.hasCommunicationCallback = null;

};

TcpRedis.prototype.sendCommunication = function(result) {
  this.sendToRedis('communication', result);

  console.log("a server has published to status redis. type:communication");
};

TcpRedis.prototype.sendData = function(result, cmdType) {
  this.sendToRedis('data', result);
	
  console.log("a server has published to status redis. type:data cmdType:" + cmdType + " id:" + result.eid);
	console.log(result.info);
};

TcpRedis.prototype.sendToRedis = function(type, result) {
  result.transType = type;
  result.createAt = timezoneTrans.format(timezoneTrans.getDate(timezone), "%Y-%m-%d %H:%M:%S");

  result = JSON.stringify(result);

  redisSend.publish('status', result);
};



TcpRedis.prototype.stratRedis = function() {
  dataCallback = this.hasDataCallback;
  communicationCallback = this.hasCommunicationCallback;

  redisReceive.on('message', function(channel, data) {
    data = JSON.parse(data);
    console.log("a server has command. type:" + data.transType);

    switch (data.transType) {
      case 'data':
        dataCallback(data);
        break;
      case 'communication':
        communicationCallback(data);
        break;
    }

  });

};
