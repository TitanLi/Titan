var jwt = require('jsonwebtoken');

module.exports = {
  login: (req, res) => {
    res.render('auth/login');
  },
  onlogin: (req, res) => {

    var result = {
      status: 200,
      message: 'success',
    };

    if (req.body.account == 'root' && req.body.password == 'root') {
      var user = {
        account: req.body.account,
        password: req.body.password
      }

      result.token = jwt.sign(user, 'swoch_nutc', {
        expiresInMinutes: 1440 // expires in 24 hours
      });
    } else {
      result.status = 400;
      result.message = 'request error';
    }

    res.json(result);
  }
};
