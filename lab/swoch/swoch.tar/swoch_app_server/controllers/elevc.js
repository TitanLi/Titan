var ioRedis = require('ioredis');
var redisSend = new ioRedis('6379', process.env.REDIS_IP);
var socketIp = process.env.SOCKET_IP || 'http://127.0.0.1:8080';
var command = new(require('../models/communication/Command'));

var result = {
  status: 200
};

command.setCommandFinishCallback(function(result) {
  result.transType = 'data';
  result = JSON.stringify(result);
  redisSend.publish('command', result);
});

module.exports = {

  index: (req, res) => {
    res.send("yangbx is good!");
  },

  show: (req, res) => {
    console.log(socketIp);

    res.render('room', {
      title: 'Rooms ' + req.params.id,
      socketIp: socketIp
    });
  },

  callInsideLevel: (req, res) => {
    command.callInside(req.body.id, req.body.level);
    res.json(result);
  },

  callInsideDisableLevel: (req, res) => {
    command.callInsideDisable(req.body.id, req.body.level);
    res.json(result);
  },

  cancelInsideLevel: (req, res) => {
    command.cancelInside(req.body.id, req.body.level);
    res.json(result);
  },

  cancelInsideDisableLevel: (req, res) => {
    command.cancelInsideDisable(req.body.id, req.body.level);
    res.json(result);
  },

  callOutsideDownLevel: (req, res) => {
    command.callOutsideDown(req.body.id, req.body.level);
    res.json(result);
  },

  callOutsideUpLevel: (req, res) => {
    command.callOutsideUp(req.body.id, req.body.level);
    res.json(result);
  },

  callOutsideDisableDownLevel: (req, res) => {
    command.callOutsideDisableDown(req.body.id, req.body.level);
    res.json(result);
  },

  callOutsideDisableUpLevel: (req, res) => {
    command.callOutsideDisableUp(req.body.id, req.body.level);
    res.json(result);
  },

  callDoorOpenOrClose: (req, res) => {
    command.callDoorStatus(req.body.id, req.body.type);
    res.json(result);
  },

  callDoorOpenOrCloseDisable: (req, res) => {
    command.callDoorStatusDisable(req.body.id, req.body.type);
    res.json(result);
  },

  callRingtone: (req, res) => {
    command.callRingtone(req.body.id);
    res.json(result);
  },

  callSpeedStatus: (req, res) => {
    command.callSpeedStatus(req.body.id);
    res.json(result);
  },

  callSpeedProtectStatus: (req, res) => {
    command.callSpeedPrototectedStatus(req.body.id);
    res.json(result);
  },

  callSpeedSetValue: (req, res) => {
    command.callSpeedSetValue(req.body.id, req.body.address, req.body.value);
    res.json(result);
  },

  callDoorControllSetValue: (req, res) => {
    command.cmdSetDoorControllStaus(req.body.id, req.body.type, req.body.value);
    res.json(result);
  },

  callSpeedSetManyValue: (req, res) => {
    command.cmdSpeedSetManyValue(req.body.id, req.body.address, req.body.value);
    res.json(result);
  }
};
