module.exports = ElevcStauts;

function ElevcStauts() {
  this.status = {};
};

ElevcStauts.prototype.getCurrentEId = function(eId) {
  return 'id_' + eId;
};

ElevcStauts.prototype.getCurrentCmdId = function(cmdId) {
  return 'cmd_' + cmdId;
};

ElevcStauts.prototype.getStatus = function(eId, cmdId) {
  eId = this.getCurrentEId(eId);
  cmdId = this.getCurrentCmdId(cmdId);

  if (this.status[eId] == null) {
    return null;
  }

  if (this.status[eId][cmdId] == null) {
    return null;
  }

  return this.status[eId][cmdId];
};

ElevcStauts.prototype.addStatus = function(eId, cmdId, command) {

  eId = this.getCurrentEId(eId);
  cmdId = this.getCurrentCmdId(cmdId);

  if (this.status[eId] == null) {
    this.status[eId] = {};
  }

  this.status[eId][cmdId] = command;
};

ElevcStauts.prototype.removeStauts = function(eId, cmdId) {
  eId = this.getCurrentEId(eId);
  cmdId = this.getCurrentCmdId(cmdId);

  delete this.status[eId][cmdId];
};

ElevcStauts.prototype.removeEId = function(eId) {
  eId = this.getCurrentEId(eId);

  delete this.status[eId];
};
