var ioRedis = require('ioredis');
//var redisReceive = new ioRedis('6379', process.env.REDIS_IP);
var redisPort = process.env.REDIS_PORT || 6379;
var redisIp = process.env.REDIS_IP || '127.0.0.1';

var redisReceive = new ioRedis(redisPort, redisIp);
var redisSend = new ioRedis(redisPort, redisIp);

redisReceive.subscribe('status', function(err, count) {});

module.exports = WebsocketRedis;

function WebsocketRedis() {
  this.dataCallback = null;
  this.disconnectCallback = null;
};

WebsocketRedis.prototype.sendCommunication = function(type) {
  var strResult = {
    transType: 'communication',
    type: null
  };

  switch (type) {
    case 0:
      strResult.type = 'get_all_data'
      break;
  }

  strResult = JSON.stringify(strResult);
  redisSend.publish('command', strResult);
  console.log('has redis command. type:communication');
};

WebsocketRedis.prototype.startRedis = function() {
  dataCallback = this.dataCallback;
  disconnectCallback = this.disconnectCallback;

  redisReceive.on('message', function(channel, data) {
    data = JSON.parse(data);

    console.log("has redis status. type:" + data.transType + " id: " + data.eid);

    switch (data.transType) {
      case 'data':

        var result = {
          eid: data.eid,
          info: null
        };

        dataCallback(result, data.info.data);

        break;
      case 'communication':

        if (data.type == 'elevc_disconnect') {
          disconnectCallback(data.eid);
        }

        break;
    }


  });

};
