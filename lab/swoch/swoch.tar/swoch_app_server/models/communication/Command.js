var sleep = function(time, callback) {
  var stop = new Date().getTime();
  while (new Date().getTime() < stop + time) {;
  }
  callback();
};

var commandFinishCallback = null;


module.exports = Command;


function Command() {};


//呼叫內部叫
Command.prototype.callInside = function(id, level) {
  this.cmdInsideLevel(id, level, 0);
};
Command.prototype.callInsideDisable = function(id, level) {
  this.cmdInsideLevel(id, level, 1);
};

//取消內部叫
Command.prototype.cancelInside = function(id, level) {
  this.cmdInsideLevel(id, level, 2);
};
Command.prototype.cancelInsideDisable = function(id, level) {
  this.cmdInsideLevel(id, level, 3);
};

//呼叫外部呼叫
Command.prototype.callOutsideDown = function(id, level) {
  this.cmdOutsideLevel(id, level, 0);
};
Command.prototype.callOutsideUp = function(id, level) {
  this.cmdOutsideLevel(id, level, 1);
};


//呼叫外部殘障呼叫
Command.prototype.callOutsideDisableDown = function(id, level) {
  this.cmdOutsideLevel(id, level, 2);
};
Command.prototype.callOutsideDisableUp = function(id, level) {
  this.cmdOutsideLevel(id, level, 3);
};


//改變門狀態
Command.prototype.callDoorStatus = function(id, type) {
  this.cmdDoorOpenOrClose(id, type);
};
Command.prototype.callDoorStatusDisable = function(id, type) {
  this.cmdDoorOpenOrClose(id, (type + 3));
};

//鈴聲
Command.prototype.callRingtone = function(id) {
  this.cmdRingtone(id, 0);
};
Command.prototype.callRingtoneDisable = function(id) {
  this.cmdRingtone(id, 1);
};

//呼叫速度指令
Command.prototype.callSpeedStatus = function(id) {
  this.cmdSpeedStaus(id, 400);
};

//呼叫速度保護指令
Command.prototype.callSpeedPrototectedStatus = function(id) {
  this.cmdSpeedProtectedStatus(id, 400);
};

Command.prototype.callSpeedSetValue = function(id, address, value) {
  this.cmdSpeedSetValue(id, address, value);
};

//改變速度保護位置的數值
Command.prototype.cmdSpeedSetValue = function(id, address, value) {
  this.executeCmd(id, [0xab, 0x07, 0x08, 0xf9, address, value]);
};

//開關門
Command.prototype.cmdDoorOpenOrClose = function(id, type) {
  var mcd = 0x18; //正常狀態
  var status = 0x01;

  if (type > 2) {
    mcd = 0x1a; //殘障狀態
  }

  switch (type % 3) {
    case 0: //開門
      status = 0x01;
      break;
    case 1: //關門
      status = 0x02;
      break;
    case 2: //延長開門
      status = 0x40;
      break;
  }

  this.executeCmd(id, [0xab, 0x96, mcd, status, 0x10]);
};

Command.prototype.cmdSpeedStaus = function(id, rangeTime) {
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0x88, 0x08]);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0x90, 0x08], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0x98, 0x08], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xa0, 0x08], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xa8, 0x08], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xb0, 0x08], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xb8, 0x08], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xc0, 0x08], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xc8, 0x08], rangeTime);
};

Command.prototype.cmdSpeedProtectedStatus = function(id, rangeTime) {
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xe2, 0x08]);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xea, 0x02], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xce, 0x09], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xd8, 0x09], rangeTime);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xc8, 0x06], rangeTime);
};

Command.prototype.cmdRingtone = function(id, type) {
  var mcd = 0x18;
  if (type > 0) {
    mcd = 0x1a;
  }

  this.executeCmd(id, [0xab, mcd, 0x08, 0x10, 0x8f]);

  this.executeCmd(id, [0xab, mcd, 0x00, 0x10, 0x97], 2000);

};

//內部叫樓服務
Command.prototype.cmdInsideLevel = function(id, level, type) {
  level = level - 1;

  var mcd = 0x00;

  switch (type) {
    case 0:
      mcd = 0x10;
      break;
    case 1:
      mcd = 0x14;
      break;
    case 2:
      mcd = 0x40;
      break;
    case 3:
      mcd = 0x44;
      break;
  }

  mcd += Math.floor(level / 8);
  var level = Math.pow(2, (level % 8));

  this.executeCmd(id, [0xab, 0x96, mcd, level, 0x34]);
};

Command.prototype.cmdOutsideLevel = function(id, level, type) {

  level = level - 1;

  var mcd = 0x00;

  switch (type) {
    case 0:
      mcd = 0x29;
      break;
    case 1:
      mcd = 0x2b;
      break;
    case 2:
      mcd = 0x29;
      level += 0x20;
      break;
    case 3:
      mcd = 0x2b;
      level += 0x20;
      break;
  }

  this.executeCmd(id, [0xab, 0xa6, mcd, level, 0x10]);
};


//指定對哪台電梯送出command
Command.prototype.executeCmd = function(id, command, runTimeAfter) {

  /*set check sum start*/
  var tmp = 0;
  command.forEach(function(value) {
    tmp += value;
  });
  tmp &= 0xff;
  tmp = 0xff - tmp + 0x01;
  tmp %= 0x100;
  command[command.length] = tmp;
  /*set check sum end*/
  result = {
    id: id,
    command: command
  };

  if (!runTimeAfter) {
    runTimeAfter = 0;
  }

  sleep(runTimeAfter, function() {
    commandFinishCallback(result);
    console.log("server has command.  " + command);
  });

};

Command.prototype.setCommandFinishCallback = function(callback) {
  commandFinishCallback = callback;
};

Command.prototype.cmdDoorControllStaus = function(id) {
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xec, 0x08, 0xe1]);
  this.executeCmd(id, [0xab, 0x07, 0x80, 0xf9, 0xf4, 0x08, 0xd9], 1000);
};

Command.prototype.cmdSetDoorControllStaus = function(id, type, value) {
  var address = 0;
  const value2 = (value * 10) / 256;
  const value1 = (value - value2);

  switch (type) {
    case 0: //delayOpenDoor
      mcd = 0xec;
      break;
    case 1: //sleepTime
      mcd = 0xee;
      break;
    case 2: //normalOpenDoor
      mcd = 0xf0;
      break;
    default: //disableOpenDoor
      mcd = 0xf2;
      break;
  }
  this.executeCmd(id, [0xab, 0x08, 0x08, 0xf9, address, value1, value2]);
};

Command.prototype.callDoorControllStaus = function(id) {
  this.cmdDoorControllStaus(id);
};

Command.prototype.cmdSpeedSetManyValue = function(id, address, value) {
  if (!Array.isArray(value)) {
    return;
  }
  if (value.length > 4) {
    return;
  }
  var cmdArray = [0xab, 0x08, 0x08, 0xf9, address];
  for (i = 0; i < value.length; i++) {
    cmdArray.push(value[i]);
  }
  this.executeCmd(id, cmdArray);
};
