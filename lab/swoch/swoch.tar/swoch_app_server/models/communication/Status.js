module.exports = Status;

function Status() {
  this.data = [];
};

Status.prototype.run = function(data) {
  var result = null;
  this.data = data;
  switch (data[1] & 0xf0) {
    case 0x80:
      switch (data[2]) {
        case 0x00:
          result = this.getStatusForLevelInfo('level_info');
          break;
        case 0x01:
          result = this.getStatusForMainLed('main_led');
          break;
        case 0x02:
          result = this.getStatusForCallLevel('call_inside');
          break;
        case 0x03:
          result = this.getStatusForCallLevel('call_outside_down');
          break;
        case 0x04:
          result = this.getStatusForCallLevel('call_outside_up');
          break;
        case 0x18:
          result = this.getStatusForDoor('door_model_info');
          break;
        case 0x1a:
          result = this.getStatusForDoor('door_model_info');
          break;
      }
      break;
    case 0x00:
      switch (data[2]) {
        case 0x00:
          switch (data[3]) {
            case 0xf9:
              switch (data[4]) {
                case 0xc8:
                  if (data[1] != 0x0c) {
                    break;
                  }
                  result = this.getStatusForSpeedOnBecause('speed_protected');
                  break;
                case 0xce:
                  if (data[1] != 0x0f) {
                    break;
                  }
                  result = this.getStatusForSpeedOnUpOrDown('speed_protected');
                  break;
                case 0xd8:
                  if (data[1] != 0x0f) {
                    break;
                  }
                  result = this.getStatusForSpeedOnUpOrDown('speed_protected');
                  break;
                case 0xe2:
                  if (data[1] != 0x0e) {
                    break;
                  }
                  result = this.getStatusForSpeedOnLeft('speed_protected');
                case 0xea:
                  if (data[1] != 0x08) {
                    break;
                  }
                  result = this.getStatusForSpeedOnLeft('speed_protected');
                  break;
                case 0xec:
                  if (data[1] != 0x0e) {
                    break;
                  }
                  result = this.getStatusForDoorControll('view3_door_controll');
                  break;
                case 0xf4:
                  // if (data[1] != 0x0a) {
                  //   break;
                  // }
                  result = this.getStatusForDoorControllLevel('view3_door_controll_level');
                  break;
                default:
                  if (data[1] != 0x0e) {
                    break;
                  }
                  result = this.getStatusForSpeed('speed_main');
                  break;
              }
              break;
          }
          break;
        default:
          result = this.getStatusForMainLedParams('main_led_parm');
          break;
      }
      break;
  }
  return result;
};

Status.prototype.setBitStr = function(data, bitCount) {
  for (var tmp = data.length; tmp < bitCount; tmp++) {
    data = '0' + data;
  }

  return data;
};

Status.prototype.getStatusForLevelInfo = function(communicationType) {
  if (this.data.length < 12) {
    return null;
  }
  var ds1 = this.setBitStr(this.data[3].toString(2), 8);
  var ds2 = this.setBitStr(this.data[4].toString(2), 8);
  var udfn = this.data[5];
  var mxfn = this.data[6];
  var bsrn = this.data[7];
  var offn = this.data[8];
  var bfst = this.setBitStr(this.data[9].toString(2), 8);
  var comp = this.data[10].toString(16);

  var res = {
    type: communicationType,
    now_level: 0,
    max_level: 0,
    prefix_level: 0,
    offn: 0,
    door: {
      front: false,
      back: false
    },
    ds1: "00000000",
    ds2: "00000000",
    company: "5f"
  };

  res.now_level = (udfn & 0x3f);
  res.max_level = mxfn;
  res.prefix_level = bsrn;
  res.offn = offn;
  res.door.front = !!+bfst.substr(6, 1);
  res.door.back = !!+bfst.substr(7, 1);
  res.ds1 = ds1;
  res.ds2 = ds2;
  res.company = comp;

  return res;
};

Status.prototype.getStatusForMainLed = function(communicationType) {
  if (this.data.length < 10) {
    return null;
  }

  var stat = this.data[3];
  var spfn = this.data[5];
  var otbf = this.setBitStr(this.data[7].toString(2), 8);
  var ctl1 = this.setBitStr(this.data[4].toString(2), 8);
  var ctl2 = this.setBitStr(this.data[6].toString(2), 8);
  var ctl3 = this.setBitStr(this.data[8].toString(2), 8);

  var res = {
    type: communicationType,
    next_level: 0,
    now_state: 0,
    otbf: {
      up: false,
      dn: false,
      bk: false,
      m1: false,
      v0: false,
      v1: false,
      v2: false,
      m2: false
    },
    stat: {
      manually: false, //12
      manually_up: false, //4
      manually_down: false //20
    },
    ctl1: {
      loop_stop: false, //11
      loop_safe: false, //3
      car_stop_up: false, //2
      car_stop_down: false, //24
      slow_down_up: false, //10
      slow_down_down: false, //18
      level_cover: false //9
    },
    ctl2: {
      uss: false, //8
      vip: false, //13
      switch_stop: false, //5
      power_cut: false, //7
      earthquake: false, //22
      recall: false //6
    },
    ctl3: {
      recall_water: false, //15
      i36: false, //26
      i35: false, //23
      i34: false, //16
      mul: false, //19
      mdl: false, //25
      ulv: false, //17
      dlv: false //1
    }
  };
  //state
  res.now_state = stat;
  //spfn
  res.next_level = (spfn & 0x3f);
  //stat
  res.stat.manually = (stat >= 0x01 && stat <= 0x05) ? true : false;
  res.stat.manually_up = (stat == 0x02 || stat == 0x03) ? true : false;
  res.stat.manually_down = (stat == 0x04 || stat == 0x05) ? true : false;
  //otbf
  res.otbf.up = !!+otbf.substr(0, 1);
  res.otbf.dn = !!+otbf.substr(1, 1);
  res.otbf.bk = !!+otbf.substr(2, 1);
  res.otbf.m1 = !!+otbf.substr(3, 1);
  res.otbf.v0 = !!+otbf.substr(4, 1);
  res.otbf.v1 = !!+otbf.substr(5, 1);
  res.otbf.v2 = !!+otbf.substr(6, 1);
  res.otbf.m2 = !!+otbf.substr(7, 1);
  //ctl1
  res.ctl1.loop_stop = !!+ctl1.substr(0, 1);
  //64
  res.ctl1.loop_safe = !!+ctl1.substr(2, 1);
  res.ctl1.car_stop_up = !!+ctl1.substr(3, 1);
  res.ctl1.car_stop_down = !!+ctl1.substr(4, 1);
  res.ctl1.slow_down_up = !!+ctl1.substr(5, 1);
  res.ctl1.slow_down_down = !!+ctl1.substr(6, 1);
  res.ctl1.level_cover = !!+ctl1.substr(7, 1);
  //ctl2
  res.ctl2.uss = !!+ctl2.substr(0, 1);
  res.ctl2.vip = !!+ctl2.substr(1, 1);
  res.ctl2.switch_stop = !!+ctl2.substr(2, 1);
  res.ctl2.power_cut = !!+ctl2.substr(3, 1);
  res.ctl2.earthquake = !!+ctl2.substr(4, 1);
  res.ctl2.recall = !!+ctl2.substr(5, 1);
  //ctl3
  res.ctl3.recall_water = !!+ctl3.substr(0, 1);
  res.ctl3.i36 = !!+ctl3.substr(1, 1);
  res.ctl3.i35 = !!+ctl3.substr(2, 1);
  res.ctl3.i34 = !!+ctl3.substr(3, 1);
  res.ctl3.mul = !!+ctl3.substr(4, 1);
  res.ctl3.mdl = !!+ctl3.substr(5, 1);
  res.ctl3.ulv = !!+ctl3.substr(6, 1);
  res.ctl3.dlv = !!+ctl3.substr(7, 1);

  return res;
};

Status.prototype.getStatusForCallLevel = function(communicationType) {
  if (this.data.length < 12) {
    return null;
  }

  var res = {
    type: communicationType,
    call: [], //全部內部所按下的樓層
    call_normal: [], //一般人士在電梯內部按下的樓層
    call_disable: [] //殘障人士在電梯內部按下的樓層
  };

  for (var tmp = 3; tmp <= 6; tmp++) {
    var bl = this.setBitStr(this.data[tmp].toString(2), 8);
    var blv = this.setBitStr(this.data[tmp + 4].toString(2), 8);

    var eightValue = (tmp - 3) * 8;
    for (var tmpJ = 0; tmpJ < 8; tmpJ++) {
      var bit = bl.length - tmpJ - 1;
      var level = tmpJ + eightValue + 1;

      var blVal = bl.substr(bit, 1);
      var blvVal = blv.substr(bit, 1);

      if (blVal == '1' || blvVal == '1') {
        res.call.push(level);
      }

      if (blVal == '1') {
        res.call_normal.push(level);
      }

      if (blvVal == '1') {
        res.call_disable.push(level);
      }
    }
  }

  return res;
};

Status.prototype.getStatusForMainLedParams = function(communicationType) {
  var led = this.data[5];

  var res = {
    type: communicationType,
    led: led.toString(16)
  };

  return res;
};

Status.prototype.getStatusForDoor = function(communicationType) {
  var disableModel = (this.data[2] == 0x1a) ? true : false;
  var status = this.data[3];

  var res = {
    type: communicationType,
    disable_model: disableModel,
    status: status
  };

  return res;
};

Status.prototype.getStatusForSpeed = function(communicationType) {
  var start = this.data[4];

  var res = {
    type: communicationType,
    start: start.toString(16),
    status: {}
  };

  res.status[(start + 0x00).toString(16)] = this.data[5];
  res.status[(start + 0x01).toString(16)] = this.data[6];
  res.status[(start + 0x02).toString(16)] = this.data[7];
  res.status[(start + 0x03).toString(16)] = this.data[8];
  res.status[(start + 0x04).toString(16)] = this.data[9];
  res.status[(start + 0x05).toString(16)] = this.data[10];
  res.status[(start + 0x06).toString(16)] = this.data[11];
  res.status[(start + 0x07).toString(16)] = this.data[12];
  return res;
};

Status.prototype.getStatusForSpeedOnLeft = function(communicationType) {
  var start = this.data[4];
  var res = {
    type: communicationType,
    start: start.toString(16),
    status: {}
  };

  if (start == 0xe2) {
    res.status[(start + 0x00).toString(16)] = this.data[5];
    res.status[(start + 0x01).toString(16)] = this.data[6];
    res.status[(start + 0x02).toString(16)] = this.data[7];
    res.status[(start + 0x03).toString(16)] = this.data[8];
    res.status[(start + 0x04).toString(16)] = this.data[9];
    res.status[(start + 0x05).toString(16)] = this.data[10];
    res.status[(start + 0x06).toString(16)] = this.data[11];
    res.status[(start + 0x07).toString(16)] = this.data[12];
  } else {
    res.status[(start + 0x00).toString(16)] = this.data[5];
    res.status[(start + 0x01).toString(16)] = this.data[6];
  }

  return res;
};

Status.prototype.getStatusForSpeedOnUpOrDown = function(communicationType) {
  var start = this.data[4];
  var res = {
    type: communicationType,
    start: start.toString(16),
    status: {}
  };

  res.status[(start + 0x00).toString(16)] = this.data[5];
  res.status[(start + 0x01).toString(16)] = this.data[6];
  res.status[(start + 0x02).toString(16)] = this.data[7];
  res.status[(start + 0x03).toString(16)] = this.data[8];
  res.status[(start + 0x04).toString(16)] = this.data[9];
  res.status[(start + 0x05).toString(16)] = this.data[10];
  res.status[(start + 0x06).toString(16)] = this.data[11];
  res.status[(start + 0x07).toString(16)] = this.data[12];
  res.status[(start + 0x08).toString(16)] = this.data[13];

  return res;
};

Status.prototype.getStatusForSpeedOnBecause = function(communicationType) {
  var start = this.data[4];
  var res = {
    type: communicationType,
    start: start.toString(16),
    status: {}
  };

  res.status[(start + 0x00).toString(16)] = this.data[5];
  res.status[(start + 0x01).toString(16)] = this.data[6];
  res.status[(start + 0x02).toString(16)] = this.data[7];
  res.status[(start + 0x03).toString(16)] = this.data[8];
  res.status[(start + 0x04).toString(16)] = this.data[9];
  res.status[(start + 0x05).toString(16)] = this.data[10];

  return res;
};

Status.prototype.getStatusForDoorControll = function(communicationType) {

  var res = {
    type: communicationType,
    delayOpenDoor: (this.data[5] + (this.data[6] * 256)) / 10,
    sleepTime: (this.data[7] + (this.data[8] * 256)) / 10,
    normalOpenDoor: (this.data[9] + (this.data[10] * 256)) / 10,
    disableOpenDoor: (this.data[11] + (this.data[12] * 256)) / 10
  };

  return res;
};

Status.prototype.getStatusForDoorControllLevel = function(communicationType) {
  var start = this.data[4];

  var res = {
    type: communicationType,
    start: start,
    status: {}
  };

  res.status[(start + 0x00).toString(16)] = this.data[5];
  res.status[(start + 0x01).toString(16)] = this.data[6];
  res.status[(start + 0x02).toString(16)] = this.data[7];
  res.status[(start + 0x03).toString(16)] = this.data[8];

  return res;
};
