var jwtMiddleware = require('./middlewares/jwt');
var cors = require('cors');
var router = require('express').Router();
var elevc = require('../controllers/elevc');

//router.use(jwtMiddleware);
router.use(cors());
router.get('/', elevc.index);
router.get('/:id', elevc.show);
//電梯內部叫樓
router.post('/level/call/inside', elevc.callInsideLevel);
router.post('/level/call/inside_disable', elevc.callInsideDisableLevel);

//電梯取消內部叫樓
router.post('/level/cancel/inside', elevc.cancelInsideLevel);
router.post('/level/cancel/inside_disable', elevc.cancelInsideDisableLevel);

//電梯外部呼叫
router.post('/level/call/outside/down', elevc.callOutsideDownLevel);
router.post('/level/call/outside/up', elevc.callOutsideUpLevel);

//電梯外部殘障呼叫
router.post('/level/call/outside_disable/down', elevc.callOutsideDisableDownLevel);
router.post('/level/call/outside_disable/up', elevc.callOutsideDisableUpLevel);

//電梯呼叫門改變
router.post('/door/call/status', elevc.callDoorOpenOrClose);
router.post('/door/call/status_disable', elevc.callDoorOpenOrCloseDisable);

//電梯鈴聲
router.post('/ringtone/call', elevc.callRingtone);
// router.post('/ringtone/call_disable', elevc.callRingtoneDisable);

// //呼叫電梯速度指令
// router.post('/speed/get_status', elevc.callSpeedStatus);
// router.post('/speed/get_prototected', elevc.callSpeedProtectStatus);

//呼叫改變速度保護位置的值
router.post('/speed/address/set_value', elevc.callSpeedSetValue);
router.post('/speed/address/set_many_value', elevc.callSpeedSetManyValue);
router.post('/door/controll/level/set_value', elevc.callDoorControllSetValue);
module.exports = router;
