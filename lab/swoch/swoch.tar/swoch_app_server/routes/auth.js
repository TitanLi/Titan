var router = require('express').Router();
var auth = require('../controllers/auth');

router.get('/login', auth.login);
router.post('/login', auth.onlogin);

module.exports = router;
