var jwtMiddleware = require('express-jwt');

var secret = 'swoch_nutc';

module.exports = jwtMiddleware({
  secret: secret //,
    //credentialsRequired: false
});
//.unless({path: ['/auth/login','/','/elevcs']})
